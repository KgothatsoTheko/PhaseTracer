package za.co.varsitycollege.st10092141.phasetracerv2

import android.app.Activity.RESULT_OK
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import za.co.varsitycollege.st10092141.phasetracerv2.databinding.FragmentNewTaskSheetBinding
import za.co.varsitycollege.st10092141.phasetracerv2.models.DataTasks
import java.time.LocalDate
import java.time.LocalTime

class NewTaskSheet (var taskItem: TaskItem?) : BottomSheetDialogFragment() {

    private lateinit var firebaseRef : DatabaseReference
    private lateinit var binding: FragmentNewTaskSheetBinding
    private lateinit var taskViewModel: TaskViewModel
    private var dueTime: LocalTime? = null
    private var dueDate: LocalDate? = null
    private var image: Uri? = null


    @RequiresApi(Build.VERSION_CODES.O)
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        firebaseRef = FirebaseDatabase.getInstance().getReference("test")

        val activity = requireActivity()
        if (taskItem != null ){
            binding.taskTitle.text = "Edit Task"
            val editable = Editable.Factory.getInstance()
            binding.name.text = editable.newEditable(taskItem!!.name)
            binding.description.text = editable.newEditable(taskItem!!.description)
            if(taskItem!!.dueTime != null) {
                dueTime = taskItem!!.dueTime!!
                updateTimeButtonText()
            }
            if(taskItem!!.dueDate != null) {
                dueDate = taskItem!!.dueDate!!
                updateDateButtonText()
            }
        }
        else {
            binding.taskTitle.text = "New Task"
        }
        taskViewModel = ViewModelProvider(activity).get(TaskViewModel::class.java)
        binding.saveButton.setOnClickListener() {
            saveAction()
        }
        binding.timePickerButton.setOnClickListener() {
            openTimePicker()
        }

        binding.datePickerButton.setOnClickListener {
            openDatePicker()
        }

        binding.imagePickerButton.setOnClickListener {
            openImagePicker()
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun openTimePicker() {
        if(dueTime == null)
            dueTime = LocalTime.now()
        val listener = TimePickerDialog.OnTimeSetListener{ _, selectedHour, selectedMinute ->
            dueTime = LocalTime.of(selectedHour, selectedMinute)
            updateTimeButtonText()
        }

        val dialog = TimePickerDialog(activity, listener, dueTime!!.hour, dueTime!!.minute, true)
        dialog.setTitle("Task Due")
        dialog.show()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun openDatePicker() {
        if (dueDate == null)
            dueDate = LocalDate.now()

        val listener = DatePickerDialog.OnDateSetListener { _, year, month, dayOfMonth ->
            dueDate = LocalDate.of(year, month + 1, dayOfMonth) // month is zero-based
            updateDateButtonText()
        }

        val dialog = DatePickerDialog(requireContext(), listener, dueDate!!.year, dueDate!!.monthValue - 1, dueDate!!.dayOfMonth)
        dialog.show()
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, IMAGE_PICKER_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == IMAGE_PICKER_REQUEST_CODE && resultCode == RESULT_OK) {
            val selectedImageUri = data?.data
            // Handle the selected image URI here
            Toast.makeText(requireContext(), "Selected image: $selectedImageUri", Toast.LENGTH_SHORT).show()
            selectedImageUri?.let { image ->
                // Update the taskItem with the selected image URI
                taskItem?.image = image
            }

        }
    }

    companion object {
        const val IMAGE_PICKER_REQUEST_CODE = 100
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun updateTimeButtonText() {
        binding.timePickerButton.text = String.format("%02d:%02d", dueTime!!.hour, dueTime!!.minute)
    }

    private fun updateDateButtonText() {
        binding.datePickerButton.text = dueDate.toString() // Format the date as needed
    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentNewTaskSheetBinding.inflate(inflater, container,false)
        // Inflate the layout for this fragment
        return binding.root

    }

    private fun saveAction() {
        val name = binding.name.text.toString()
        val description = binding.description.text.toString()
        if(taskItem == null) {
            val newTask = TaskItem(name, description, dueTime, dueDate, image, null)
            taskViewModel.addTaskItem(newTask)

            addToDatabase()
        }
        else {
            taskViewModel.updateTaskItem(taskItem!!.id, name, description, dueTime, dueDate, image)
        }
        binding.name.setText("")
        binding.description.setText("")
        dismiss()

    }

    private fun addToDatabase() {
        val category = binding.name.text.toString()
        val name = binding.description.text.toString()
        val dueDate = dueDate.toString()
        val dueTime = dueTime.toString()
        val taskID = firebaseRef.push().key!!

        val test = DataTasks(taskID, category, name, dueTime, dueDate)

        firebaseRef.child(taskID).setValue(test)

    }

}