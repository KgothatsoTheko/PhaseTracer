package za.co.varsitycollege.st10092141.phasetracerv2

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import za.co.varsitycollege.st10092141.phasetracerv2.adapter.RvTasksAdapter
import za.co.varsitycollege.st10092141.phasetracerv2.databinding.FragmentDataTasksBinding
import za.co.varsitycollege.st10092141.phasetracerv2.models.DataTasks

class DatabaseTasksFragment : Fragment() {

    private lateinit var tasksList: ArrayList<DataTasks>
    private lateinit var firebaseRef: DatabaseReference
    private var _binding: FragmentDataTasksBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentDataTasksBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Enable edge-to-edge if needed
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        firebaseRef = FirebaseDatabase.getInstance().getReference("test")
        tasksList = arrayListOf()

        fetchData()

        binding.rvTasks.apply {
            setHasFixedSize(true)
            layoutManager = LinearLayoutManager(requireContext())
        }
    }

    private fun fetchData() {
        firebaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                tasksList.clear()
                if (snapshot.exists()) {
                    for (taskSnap in snapshot.children) {
                        val tasks = taskSnap.getValue(DataTasks::class.java)
                        tasks?.let { tasksList.add(it) }
                    }
                }
                val rvAdapter = RvTasksAdapter(tasksList)
                binding.rvTasks.adapter = rvAdapter
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
