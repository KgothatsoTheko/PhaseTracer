package za.co.varsitycollege.st10092141.phasetracerv2.models

import android.net.Uri
import java.time.LocalDate
import java.time.LocalTime
import java.util.UUID

data class DataTasks(
    val id : String? = null,
    var category: String? = null,
    var name: String? = null,
    var dueTime: String? = null,
    var dueDate: String? = null,
)
