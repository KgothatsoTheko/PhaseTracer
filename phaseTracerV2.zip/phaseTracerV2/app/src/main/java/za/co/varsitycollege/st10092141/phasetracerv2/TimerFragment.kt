package za.co.varsitycollege.st10092141.phasetracerv2

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import za.co.varsitycollege.st10092141.phasetracerv2.databinding.FragmentTimerBinding


class TimerFragment : Fragment() {

    private lateinit var binding: FragmentTimerBinding
    private var timerStarted = false
    private var time = 0.0
    private lateinit var handler: Handler
    private lateinit var runnable: Runnable


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentTimerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnStart.setOnClickListener { startStopTimer() }
        binding.btnReset.setOnClickListener { resetTimer() }
        handler = Handler(Looper.getMainLooper())
        runnable = Runnable { updateTimer() }
    }

    private fun resetTimer() {
        stopTimer()
        time = 0.0
        binding.tvcountdown.text = getTimeStringFromDouble(time)
    }

    private fun startStopTimer() {
        if (timerStarted)
            stopTimer()
        else
            startTimer()
    }

    private fun startTimer() {
        binding.btnStart.text = "Stop"
        timerStarted = true
        handler.postDelayed(runnable, 1000)
    }

    private fun stopTimer() {
        binding.btnStart.text = "Start"
        timerStarted = false
        handler.removeCallbacks(runnable)
    }

    private fun updateTimer() {
        time++
        binding.tvcountdown.text = getTimeStringFromDouble(time)
        handler.postDelayed(runnable, 1000)
    }

    private fun getTimeStringFromDouble(time: Double): String {
        val resultsInt = time.toInt()
        val hours = resultsInt % 86400 / 3600
        val minutes = resultsInt % 86400 % 3600 / 60
        val seconds = resultsInt % 86400 % 3600 % 60
        return makeTimeString(hours, minutes, seconds)
    }

    private fun makeTimeString(hour: Int, min: Int, sec: Int): String =
        String.format("%02d:%02d:%02d", hour, min, sec)


}