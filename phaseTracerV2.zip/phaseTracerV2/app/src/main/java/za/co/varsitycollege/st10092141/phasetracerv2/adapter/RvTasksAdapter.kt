package za.co.varsitycollege.st10092141.phasetracerv2.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import za.co.varsitycollege.st10092141.phasetracerv2.databinding.RvTasksItemBinding
import za.co.varsitycollege.st10092141.phasetracerv2.models.DataTasks

class RvTasksAdapter(private  val taskList : java.util.ArrayList<DataTasks>) : RecyclerView.Adapter<RvTasksAdapter.ViewHolder>() {
    class ViewHolder(val binding: RvTasksItemBinding) : RecyclerView.ViewHolder(binding.root) {

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            RvTasksItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return taskList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = taskList[position]
        holder.apply {
            binding.apply {
                tvCategoryItem.text = currentItem.category
                tvNameItem.text = currentItem.name
                tvDueTimeItem.text = currentItem.dueTime
                tvDueDateItem.text = currentItem.dueDate
                tvIdItem.text = currentItem.id
            }
        }
    }
}